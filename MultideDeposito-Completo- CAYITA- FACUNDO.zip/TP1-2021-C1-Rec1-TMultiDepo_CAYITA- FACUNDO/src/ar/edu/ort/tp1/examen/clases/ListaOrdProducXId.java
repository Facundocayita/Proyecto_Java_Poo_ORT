package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ListaOrdenadaNodos;

public class ListaOrdProducXId extends ListaOrdenadaNodos<Integer, Producto> {

	@Override
	public int compare(Producto producto1, Producto producto2) {
		// TODO Auto-generated method stub
		return compareByKey(producto1.getId(), producto2);
	}

	@Override
	public int compareByKey(Integer id, Producto producto) {
		// TODO Auto-generated method stub
		return id - producto.getId();
	}

}
