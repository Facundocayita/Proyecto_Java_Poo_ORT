package ar.edu.ort.tp1.examen.clases;

public class Mejora extends Tarea {
	
	private Tipo tipo = Tipo.MEJORA;
	private String nombreSistAMejorar;
	
	

	public Mejora(String descripcion, int diaInicio, int mesInicio, int anioInicio, Prioridad prioridad, String sistema) {
		super(descripcion, diaInicio, mesInicio, anioInicio, prioridad);
		this.nombreSistAMejorar = sistema;
	}

	

	@Override
	public boolean estaVencido() {
		return false;
	}



	@Override
	public Tipo getTipo() {
		return this.tipo;
	}
	
	@Override
	protected String completarMostrar() {
		return "Se mejorara el sistema "+this.nombreSistAMejorar;
	}

	

}
