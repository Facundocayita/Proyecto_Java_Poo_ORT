package ar.edu.ort.tp1.examen.clases;

import java.util.Iterator;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;
import ar.edu.ort.tp1.tdas.interfaces.ListaOrdenada;
//TODO
public class Gestor{
	
	private ColaNodos<Tarea>[][] mTareas = new ColaNodos[Prioridad.values().length][Tipo.values().length];



	public Gestor() {
		super();
		inicialiarMatriz();
	}

	public void registrarTarea(Tarea tarea) {
		if (tarea == null) {
			throw new IllegalArgumentException("Tarea nula");
		}
		
		mTareas[tarea.getPrioridad().ordinal()][tarea.getTipo().ordinal()].add(tarea);
		System.out.println("Tarea registrada "+tarea.getTipo()+" - "+tarea.estaVencido());
	}

	public void listarTareasPorDescripcion(Prioridad p) {
		ListaTareasPorDescrip lTareasXDesc = generarListaTareasPorDescripcion(p);
		for (Tarea tarea : lTareasXDesc) {
			tarea.mostrar();
		}
	}

	private ListaTareasPorDescrip generarListaTareasPorDescripcion(Prioridad p) {
		ListaTareasPorDescrip lTareasXDesc = new ListaTareasPorDescrip();
		
		ColaNodos<Tarea>[] ColaTareaPrioridad = mTareas[p.ordinal()];
		for (int i = 0; i < ColaTareaPrioridad.length; i++) {
			procesarCola(ColaTareaPrioridad[i], lTareasXDesc);
		}
		
		return lTareasXDesc;
	}

	private void procesarCola(ColaNodos<Tarea> colaNodos, ListaTareasPorDescrip lTareasXDesc) {
		colaNodos.add(null);
		Tarea t = colaNodos.remove();
		
		while(t != null) {
			lTareasXDesc.add(t);
			colaNodos.add(t);
			t = colaNodos.remove();
		}
		
	}

	private void inicialiarMatriz() {
		for (int i = 0; i < mTareas.length; i++) {
			for (int j = 0; j < mTareas[i].length; j++) {
				mTareas[i][j] = new ColaNodos<Tarea>();	
			}
		}
		
	}

	
}
