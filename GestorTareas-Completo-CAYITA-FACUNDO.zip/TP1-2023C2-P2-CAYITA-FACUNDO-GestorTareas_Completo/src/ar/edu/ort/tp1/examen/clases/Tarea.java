package ar.edu.ort.tp1.examen.clases;
//TODO
public abstract class Tarea implements Mostrable, Vigencia {

	private static final String MSG_PRIORIDAD_INVALIDA = "Prioridad inv�lida";
	private static final String MSG_FECHA_INVALIDA = "Fecha de inicio inv�lida";
	private static final String MSG_DESCRIPCION_INVALIDA = "La descripcion no puede ser nula ni vac�a";
	
	private Prioridad prioridad;
	private String descripcion;
	private Fecha fechaDeInicio;
	
	
	public Tarea(String descripcion, int diaInicio, int mesInicio, int anioInicio, Prioridad prioridad) {
		super();
		setPrioridad(prioridad);
		setDescripcion(descripcion);
		setFechaInicio(diaInicio,mesInicio,anioInicio);
	}
	

	private void setFechaInicio(int diaInicio, int mesInicio, int anioInicio) {
		try {
			fechaDeInicio =  new Fecha(diaInicio, mesInicio, anioInicio);
		}catch (RuntimeException e) {
			throw new IllegalArgumentException(MSG_FECHA_INVALIDA);
		}
	}

	private void setDescripcion(String descripcion) {
		if(descripcion == null || descripcion.isBlank()) {
			throw new IllegalArgumentException(MSG_DESCRIPCION_INVALIDA);
		}	
		
		this.descripcion = descripcion;
	}

	private void setPrioridad(Prioridad prioridad) {
		if(prioridad == null) {
			throw new IllegalArgumentException(MSG_PRIORIDAD_INVALIDA);

		}  
		this.prioridad =  prioridad;
	}
	
	public Prioridad getPrioridad() {
		return this.prioridad;
	}
	public abstract Tipo getTipo();
	
	@Override
	public boolean estaVigente() {
		boolean vigente = false;
		if(this.fechaDeInicio.diasDesde(Fecha.hoy()) >= 0) {
			vigente =  true;
		}
		return vigente;
	}
	
	
	public String textoVencido() {
		return estaVencido() ? "Esta vencida" : "No esta vencida";
	}
	
	
	@Override
	public void mostrar() {
		System.out.println(getTipo()+"Descripcion: "+this.descripcion+"- Prioridad: "+this.prioridad+
				"- Fecha de inicio: "+this.fechaDeInicio.toString()+" "+textoVencido()+"- "+completarMostrar());

	}


	protected abstract String completarMostrar();


	public String getDescripcion() {
		return descripcion;
	}
	
	
	

}
