package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;

public class PilaProducto extends PilaNodos<Producto> {

	public PilaProducto() {
	}
	public PilaProducto(int profundidadEstanteria) {
		super(profundidadEstanteria);
	}

	
}
