package ar.edu.ort.tp1.tdas.interfaces;

public interface Checkable {
	
	void checkEmptiness() throws RuntimeException;

	void checkFullness() throws RuntimeException;

}
