package ar.edu.ort.tp1.examen.clases;

public class Raqueta extends Producto {

	private static final String MSG_TAMANIO_ARO_INVALIDO = "Tama�o de aro inv�lido.";
	private static final String MSG_RAQUETA = "La raqueta tiene un tama�o de aro %d es de la marca %s y tiene un id %d\n";
	private static final int LIM_MENOR_TAM_ARO = 93;
	private static final int LIM_MAYOR_TAM_ARO = 120;
	private int tamanioAro;
	
	
	
	public Raqueta(int id, String marca, int tamanioAro) {
		super(id, marca);
		setTamanioAro(tamanioAro);
	}



	private void setTamanioAro(int tamanioAro) {
		if(tamanioAro <LIM_MENOR_TAM_ARO || tamanioAro >  LIM_MAYOR_TAM_ARO) {
			throw new IllegalArgumentException(MSG_TAMANIO_ARO_INVALIDO);
		}
		this.tamanioAro = tamanioAro;
	}



	@Override
	public void mostrar() {
		System.out.println(String.format(MSG_RAQUETA, this.tamanioAro, super.getMarca(), super.getId()));// TODO Auto-generated method stub
		
	}
	
	
	
}
