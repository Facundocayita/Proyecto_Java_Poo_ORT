package ar.edu.ort.tp1.examen.clases;

public class Auditoria extends TareaVencible {
	
	private boolean esExterna;
	private Tipo tipo = Tipo.AUDITORIA;

	public Auditoria(String descripcion, int diaInicio, int mesInicio, int anioInicio, Prioridad prioridad, int diaVto,
			int mesVto, int anioVto, boolean esExterna) {
		super(descripcion, diaInicio, mesInicio, anioInicio, prioridad, diaVto, mesVto, anioVto);
		this.esExterna = esExterna;
	}


	@Override
	public Tipo getTipo() {
		return this.tipo;
	}
	
	@Override
	protected String completarMostrar() {
		return this.esExterna? "Externa": "Interna";
	}

	

	

}
