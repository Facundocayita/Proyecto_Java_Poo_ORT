package ar.edu.ort.tp1.examen.clases;

public class Bug extends TareaVencible {
	
	private boolean esCritico;
	private Tipo tipo = Tipo.BUG;

	public Bug(String descripcion, int diaInicio, int mesInicio, int anioInicio, Prioridad prioridad, int diaVto,
			int mesVto, int anioVto, boolean esCritico) {
		super(descripcion, diaInicio, mesInicio, anioInicio, prioridad, diaVto, mesVto, anioVto);
		this.esCritico = esCritico;
	}

	@Override
	public boolean estaVencido() {
		boolean vencido = false;
		if(esCritico) {
			vencido = super.estaVencido();
		}else {
			if(super.diasDeVencimiento() > 10) {
				vencido = true;
			}
		}
		return vencido;
	}

	@Override
	public Tipo getTipo() {
		return this.tipo;
	}

	@Override
	protected String completarMostrar() {
		return this.esCritico? "Es critico": "No es critico";
	}

	

}
