package ar.edu.ort.tp1.examen.clases;

public abstract class TareaVencible extends Tarea {

	private static final String MSG_FECHA_VTO_INVALIDA = "Fecha de vencimiento inv�lida";
	private Fecha fechaVto;

	public TareaVencible(String descripcion, int diaInicio, int mesInicio, int anioInicio, Prioridad prioridad,
			int diaVto, int mesVto, int anioVto) {
		super(descripcion, diaInicio, mesInicio, anioInicio, prioridad);
		setFechaVto(diaVto,mesVto,anioVto);
	}

	private void setFechaVto(int diaVto, int mesVto, int anioVto) {
		try {
			fechaVto =  new Fecha(diaVto, mesVto, anioVto);
		}catch (RuntimeException e) {
			throw new IllegalArgumentException(MSG_FECHA_VTO_INVALIDA);
		}
		
	}
	
	@Override
	public boolean estaVencido() {
		boolean vencida = false;
		if(this.fechaVto.diasDesde(Fecha.hoy()) < 0) {
			vencida =  true;
		}
		return vencida;
	}

	public int diasDeVencimiento() {
		return (int) this.fechaVto.diasDesde(Fecha.hoy());
	}
	
	
	
	

}
