package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ListaOrdenadaNodos;

public class ListaTareasPorDescrip extends ListaOrdenadaNodos<String, Tarea> {

	@Override
	public int compare(Tarea tarea1, Tarea tarea2) {
		return compareByKey(tarea1.getDescripcion(), tarea2);
	}

	@Override
	public int compareByKey(String descp, Tarea tarea) {
		return descp.compareTo(tarea.getDescripcion());
	}

}
