package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.interfaces.ListaOrdenada;

public class Deposito implements Depositante<Producto, Integer> {

	private static final String MSG_TIPO_PROD_INVALIDO = "Tipo de producto inv�lido";
	private static final String MSG_NO_PUDO_DEPOSITAR = "No se pudo depositar el producto.";
	private static final String MSG_PROF_INVALIDO = "Profundidad de estanter�a inv�lido";
	private static final int ALTO_ESTANTERIA = 3;
	private static final int ANCHO_ESTANTERIA = 4;
	private static final int PROFUNDIDAD_ESTANTERIA_MAX = 10;
	private static final int PROFUNDIDAD_ESTANTERIA_MIN = 2;
	private static final int FILA_PELOTA = 0;
	private static final int FILA_RAQUETA = 1;
	private static final int FILA_BOLSO = 2;
	private Estante[][] estanteria;
	private ListaOrdProducXId productosXId;

	// TODO Completar

	// TODO Completar
	public Deposito(int profundidadEstanteria) {
		if(profundidadEstanteria < PROFUNDIDAD_ESTANTERIA_MIN || profundidadEstanteria >PROFUNDIDAD_ESTANTERIA_MAX) {
			throw new IllegalArgumentException(MSG_PROF_INVALIDO);
		}

		crearEstanteria(profundidadEstanteria);
		productosXId =  new ListaOrdProducXId();

	}

	private void crearEstanteria(int profundidadEstanteria) {
		estanteria = new Estante[ALTO_ESTANTERIA][ANCHO_ESTANTERIA];
		for (int i = 0; i < estanteria.length; i++) {
			for (int j = 0; j < estanteria[i].length; j++) {
				estanteria[i][j] = new Estante(profundidadEstanteria);
			}
		}
		
	}

	@Override
	public void depositar(Producto producto) {
		int fila =  obtenerFila(producto);
		boolean depositado = false;
		int i = 0;
		if(fila > -1) {
			while(i < estanteria[fila].length && !depositado) {
				try{
					estanteria[fila][i].depositar(producto);
					depositado = true;
					this.productosXId.add(producto);
					producto.mostrar();
				}catch(RuntimeException re) {
				//	System.out.println(MSG_NO_PUDO_DEPOSITAR);// VER ESTO PARA QUE NO LO IMPRIMA SIEMPRE HASTA QUE RECORRA TODAS LAS COLUMNAS
					i++;
					if(i >=estanteria[fila].length ) {
						System.out.println(MSG_NO_PUDO_DEPOSITAR);
					}
				}
			}
		}else {
			throw new IllegalArgumentException(MSG_TIPO_PROD_INVALIDO);
		}
	}

	private int obtenerFila(Producto producto) {
		int fila = -1;
		if(producto instanceof Pelota) {
			fila = FILA_PELOTA;
		}else if (producto instanceof Raqueta) {
			fila = FILA_RAQUETA;
		}else if (producto instanceof Bolso) {
			fila = FILA_BOLSO;
		}
		return fila;
	}

	@Override
	public Producto retirarPorId(Integer idProducto) {
		Producto p = this.productosXId.search(idProducto);
		if(p != null) {
			this.productosXId.remove(p);
		}
		return p;
	}
	
	public boolean productoDepositado(int idProducto) {
		return this.productosXId.exists(idProducto);
	}


	// TODO Completar
	/**
	 * Deposita el producto recibido en la estanter�a, en la fila que le corresponde
	 * seg�n su producto, en el el primer estante que tenga lugar.
	 */
	
	/**
	 * Indica si un producto se encuentra depositado
	 * @param idProducto
	 * @return
	 */

	/**
	 * Retira un producto en base a su ID
	 */

}
