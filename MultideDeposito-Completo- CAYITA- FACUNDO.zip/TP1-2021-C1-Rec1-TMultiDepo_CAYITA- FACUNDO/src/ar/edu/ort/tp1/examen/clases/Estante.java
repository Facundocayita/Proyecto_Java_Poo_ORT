package ar.edu.ort.tp1.examen.clases;

public class Estante implements Depositante<Producto, Integer> {

	private PilaProducto estante;

	public Estante(int profundidadEstanteria) {
		estante =  new PilaProducto(profundidadEstanteria);
	}

	@Override
	public void depositar(Producto elemento) {
		if(estante.isFull()) {
			throw new IllegalArgumentException("");
		}
		estante.push(elemento);
	}

	@Override
	public Producto retirarPorId(Integer id) {
		Producto buscado = null;
		PilaProducto pilaAux = new PilaProducto();
		Producto aux = this.estante.pop();
		
		while(!estante.isEmpty() && buscado == null) {
		if(aux.mismoId(id)) {
			buscado = aux;
		}else {
			pilaAux.push(aux);
			aux = this.estante.pop();
		}
		}
		
		while(!pilaAux.isEmpty()) {
			this.estante.push(pilaAux.pop());
		}
		return buscado;
	}

	/**
	 * Agrega un elemento al estante siempre y cuando haya lugar, sino, deber� emitir la excepci�n que corresponda..
	 */

	/**
	 * Retira el producto de la estanter�a por su id
	 */

}
